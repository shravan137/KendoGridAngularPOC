import { Component, Input, Output, EventEmitter, OnInit, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { SelectableSettings } from '@progress/kendo-angular-grid';
import { GridDataResult, PageChangeEvent } from "@progress/kendo-angular-grid";
import { SortDescriptor, orderBy, filterBy, CompositeFilterDescriptor, State } from '@progress/kendo-data-query';
import { IColumn } from './../column';

@Component({
    selector: 'custom-grid',
    templateUrl: './grid.component.html',
    styleUrls: ['./grid.component.scss']
})
export class GridComponent implements OnInit {
    public gridData: GridDataResult;
    public formGroup: FormGroup;
    public checkboxOnly = false;
    public selectableSettings: SelectableSettings;
    private editedRowIndex: number;
    public pageSize = 5;
    public skip = 0;
    public previousNext = true;
    public pageSizes = true;
    public info = true;
    @Input() public inputGridData: any;
    public kendoGriddata: any;
    public originalData: any;
    public sort: SortDescriptor[] = [];
    public filter: CompositeFilterDescriptor;
    public checkAll: any;
    public mySelection: any[] = [];
    public hasChanges: boolean = false;
    public categories: any[];
    public buttonCount: number = 10;
    @Input() public columns: IColumn[];
    @Input() public childColumns: IColumn[];
    @Input() public categoryDDLData: any[];
    @Output() public outputData: EventEmitter<any> = new EventEmitter();
    public state: State = {
        skip: 0,
        take: 5,

        // Initial filter descriptor
        filter: {
            logic: 'and',
            // filters: [{ field: 'ProductName', operator: 'contains', value: '' }]
            filters: []
        }
    };


    constructor() { }

    ngOnInit() {
        this.kendoGriddata = this.inputGridData;
        this.originalData = JSON.parse(JSON.stringify(this.kendoGriddata));
        this.categories = this.categoryDDLData;
        // this.setSelectableSettings();
        this.loadGridData();
    }

    public setSelectableSettings(): void {
        this.selectableSettings = {
            checkboxOnly: this.checkboxOnly,
            mode: "multiple"
        };
    }
    //#region Parent Grid Code

    public addHandler({ sender }) {
        alert("asd");
        this.closeEditor(sender);
        this.formGroup = this.createFormGroup({});
        sender.addRow(this.formGroup);
    }

    public editHandler({ sender, rowIndex, dataItem }) {
        this.closeEditor(sender);

        this.formGroup = this.createFormGroup(dataItem);
        this.editedRowIndex = rowIndex;

        sender.editRow(rowIndex, this.formGroup);
        // this.hasChanges = true;
    }

    public cancelHandler({ sender, rowIndex }) {
        this.closeEditor(sender, rowIndex);
        // this.hasChanges = false;
    }

    public saveHandler({ sender, rowIndex, formGroup, isNew }) {
        // const item = { ...formGroup.value };
        const item = formGroup.value;

        isNew ? this.gridData.data.unshift(item) : this.gridData.data.splice(rowIndex, 1, item);
        isNew ? this.kendoGriddata.unshift(item) : this.kendoGriddata.splice(rowIndex, 1, item);

        sender.closeRow(rowIndex);
        this.hasChanges = true;
    }

    public removeHandler({ dataItem }) {
        const index = this.gridData.data.findIndex(({ ServiceID }) => ServiceID === dataItem.ServiceID);
        this.gridData.data.splice(index, 1);
        this.kendoGriddata = this.kendoGriddata.filter(item => item.ServiceID !== dataItem.ServiceID);
        this.loadGridData();
        this.hasChanges = true;
        //this.gridData = this.gridData.filter(item => item.ProductID !== dataItem.ProductID);
    }

    private closeEditor(grid, rowIndex = this.editedRowIndex) {
        grid.closeRow(rowIndex);
        this.editedRowIndex = undefined;
        this.formGroup = undefined;
    }

    protected pageChange({ skip, take }: PageChangeEvent): void {
        this.skip = skip;
        this.pageSize = take;
        if (this.filter && this.filter.filters.length != 0) {
            this.filterChange(this.filter, true);
        } else {
            this.loadGridData();
        }
    }

    public sortChange(sort: SortDescriptor[], dataItem: any): void {
        this.sort = sort;
        this.sortGrid();
    }

    private sortGrid(): void {
        this.kendoGriddata = orderBy(this.kendoGriddata, this.sort);
        this.loadGridData();
    }

    public filterChange(filter: any, isPageChange: boolean = false): void {
        if (!isPageChange) {
            this.skip = 0;
            this.pageSize = 5;
        }
        this.filter = filter;
        this.gridData.data = filterBy(this.kendoGriddata, filter);
        if (this.filter.filters.length == 0) {
            this.loadGridData();
        } else {
            this.gridData = {
                data: this.gridData.data.slice(this.skip, this.skip + this.pageSize),
                total: this.gridData.data.length
            };
        }
    }

    public cancelChanges(grid: any): void {
        this.gridData = {
            data: this.originalData.slice(this.skip, this.skip + this.pageSize),
            total: this.originalData.length
        };
        this.hasChanges = false;
    }

    public saveChanges(grid: any): void {
        if (!this.hasChanges) {
            alert("No changes to save");
        }
        else if (this.formGroup && this.formGroup.status == "INVALID") {
            alert("please fill all mandatory fields");
        } else {
            // alert(this.kendoGriddata);
            this.outputData.emit(this.kendoGriddata);
            alert("data emitted successfully");
        }
    }

    //#endregion

    public category(id: number): any {
        return this.categories.find(x => x.CategoryID === id);
    }

    private createFormGroup(dataItem) {
        return this.createFormGroupDynamic(dataItem, this.columns);
    };

    private createChildFormGroup(dataItem) {
        return this.createFormGroupDynamic(dataItem, this.childColumns);
    };

    private createFormGroupDynamic(dataItem: any, columns: IColumn[]) {
        let group: any = {};
        columns.forEach(col => {

            group[col.field] = col.required ? new FormControl(dataItem[col.field], col.type == "numeric" ? Validators.compose([Validators.required, Validators.pattern('(?!0)\\d+(?:\\.\\d+)?$')]) : Validators.required)
                : new FormControl(dataItem[col.field])

        });
        if (dataItem.children) {
            group['children'] = new FormControl(dataItem.children)
        }
        return new FormGroup(group);
    }


    private loadGridData(): void {
        this.gridData = {
            data: this.kendoGriddata.slice(this.skip, this.skip + this.pageSize),
            total: this.kendoGriddata.length
        };     
    }

    // onClick() {
    //     alert(this.gridData);
    // }

    public cgEditHandler({ sender, rowIndex, dataItem }) {
        this.closeEditor(sender);
        this.formGroup = this.createChildFormGroup(dataItem);
        this.editedRowIndex = rowIndex;
        sender.editRow(rowIndex, this.formGroup);
        // this.hasChanges = true;
    }

    public cgCancelHandler({ sender, rowIndex }) {
        this.closeEditor(sender, rowIndex)
    }

    public cgSaveHandler({ sender, rowIndex, formGroup, isNew }) {
        const item = formGroup.value;
        isNew ? this.gridData.data.unshift(item) : sender.data.splice(rowIndex, 1, item);
        sender.closeRow(rowIndex);
        this.hasChanges = true;
    }

    public cgRemoveHandler({ sender, dataItem }) {
        const index = sender.data.findIndex(({ id }) => id === dataItem.id);
        sender = sender.data.splice(index, 1);
    }

    public sortChangeChild(sort: SortDescriptor[], dataItem: any): void {
        this.sort = sort;
        dataItem.children = orderBy(dataItem.children, this.sort);
    }

    filterChangeChild(filter: any, dataItem: any): void {
        this.kendoGriddata = JSON.parse(JSON.stringify(this.originalData));
        this.filter = filter;
        var data = this.kendoGriddata.filter(x => x.ServiceID == dataItem.ServiceID)[0];
        dataItem.children = filterBy(data.children, filter);
        if (this.filter.filters.length == 0) {
            this.loadGridData();
        } else {
            this.gridData = {
                data: this.gridData.data.slice(this.skip, this.skip + this.pageSize),
                total: this.gridData.data.length
            };
        }
    }

}
