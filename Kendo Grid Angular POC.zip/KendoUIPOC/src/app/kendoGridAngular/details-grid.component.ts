import { Component, ViewChild, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { GridDataResult, GridComponent, PageChangeEvent } from '@progress/kendo-angular-grid';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { IColumn } from './../column';
import { State, filterBy, CompositeFilterDescriptor, SortDescriptor, orderBy } from '@progress/kendo-data-query';
import { isUndefined } from 'util';

@Component({
    selector: 'details-grid',
    templateUrl: './details-grid.component.html'
})

export class DetailGridComponent implements OnInit {
    public inputGridData: GridDataResult;
    public previousNext = true;
    public info = true;
    public pageSizes = true;
    private editedRowIndex: number;
    public formGroup: FormGroup;
    public view: Observable<GridDataResult>;
    public skip = 0;
    public pageSize = 5;
    public filter: CompositeFilterDescriptor;
    public sort: SortDescriptor[] = [];
    @Input() public inputData: any;
    @Input() public gridColumns: any;
    hasChild: boolean = false;
    public state: State = {
        skip: 0,
        take: 5,

        // Initial filter descriptor
        filter: {
            logic: 'and',
            // filters: [{ field: 'ProductName', operator: 'contains', value: '' }]
            filters: []
        }
    };

    constructor() { }

    public ngOnInit(): void {
        if (this.inputData[0].children) {
            this.hasChild = true;
        }
        this.loadGridData();
    }

    protected pageChange({ skip, take }: PageChangeEvent): void {
        this.skip = skip;
        this.pageSize = take;
        // this.loadGridData();

        if (this.filter && this.filter.filters.length != 0) {
            this.filterChange(this.filter, true);
        }
        else {
            this.loadGridData();
        }
        if ((isUndefined(this.filter) || this.filter.filters.length == 0) && this.sort.length > 0) {
            this.sortChange(this.sort, null);
        }
    }

    public editHandler({ sender, rowIndex, dataItem }) {
        this.closeEditor(sender);
        this.formGroup = this.createChildFormGroup(dataItem);
        this.editedRowIndex = rowIndex;
        sender.editRow(rowIndex, this.formGroup);
        // this.hasChanges = true;
    }

    private closeEditor(grid, rowIndex = this.editedRowIndex) {
        grid.closeRow(rowIndex);
        this.editedRowIndex = undefined;
        this.formGroup = undefined;
    }

    public cancelHandler({ sender, rowIndex }) {
        this.closeEditor(sender, rowIndex)
    }

    public saveHandler({ sender, rowIndex, formGroup, isNew }) {
        const item = formGroup.value;

        isNew ? this.inputData.unshift(item) : sender.data.splice(rowIndex, 1, item);
        isNew ? this.inputGridData.data.unshift(item) : sender.data.splice(rowIndex, 1, item);
        sender.closeRow(rowIndex);
        this.loadGridData();
    }

    public removeHandler({ sender, dataItem }) {
        const index = this.inputGridData.data.findIndex(({ ServiceID }) => ServiceID === dataItem.ServiceID);
        this.inputGridData.data.splice(index, 1);
        this.inputData = this.inputData.filter(item => item.ServiceID !== dataItem.ServiceID);
        this.loadGridData();
    }

    public addHandler({ sender }) {
        this.closeEditor(sender);
        this.formGroup = this.createFormGroup({});
        sender.addRow(this.formGroup);
    }

    filterChange(filter: any, isPageChange: boolean = false): void {
        if (!isPageChange) {
            this.skip = 0;
        }
        this.filter = filter;
        this.inputGridData.data = filterBy(this.inputData, filter);
        if (this.filter.filters.length == 0) {
            this.loadGridData();
        } else {
            if (this.sort.length > 0) {
                this.inputGridData.data = orderBy(this.inputGridData.data, this.sort);
            }
            this.inputGridData = {
                data: this.inputGridData.data.slice(this.skip, this.skip + this.pageSize),
                total: this.inputGridData.data.length
            };
        }
    }

    sortChange(sort: SortDescriptor[], dataItem: any): void {
        this.sort = sort;
        this.inputGridData.data = orderBy(this.inputData, this.sort);
        this.sortData();
    }

    private sortData() {
        this.inputGridData = {
            data: this.inputGridData.data.slice(this.skip, this.skip + this.pageSize),
            total: this.inputGridData.data.length
        };
    }

    private createFormGroup(dataItem) {
        return this.createFormGroupDynamic(dataItem, this.gridColumns);
    };

    private loadGridData(): void {
        this.inputGridData = {
            data: this.inputData.slice(this.skip, this.skip + this.pageSize),
            total: this.inputData.length
        };
    }

    private createChildFormGroup(dataItem) {
        return this.createFormGroupDynamic(dataItem, this.gridColumns);
    };

    private createFormGroupDynamic(dataItem: any, columns: IColumn[]) {
        let group: any = {};
        columns.forEach(col => {

            group[col.field] = col.required ? new FormControl(dataItem[col.field], col.type == "numeric" ? Validators.compose([Validators.required, Validators.pattern('(?!0)\\d+(?:\\.\\d+)?$')]) : Validators.required)
                : new FormControl(dataItem[col.field])

        });
        if (dataItem.children) {
            group['children'] = new FormControl(dataItem.children)
        }
        return new FormGroup(group);
    }
}
