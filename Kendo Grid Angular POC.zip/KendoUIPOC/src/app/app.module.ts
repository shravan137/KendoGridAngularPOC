import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GridModule } from '@progress/kendo-angular-grid';
import { ReactiveFormsModule } from '@angular/forms';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { AppComponent } from './app.component';
import { PopupModule } from '@progress/kendo-angular-popup';
import { PopupAnchorDirective } from './popup.anchor-target.directive';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { DropDownListFilterComponent } from './dropdownlist-filter.component';
import { GridComponent } from '../app/kendoGridAngular/grid.component';
import { DetailGridComponent } from '../app/kendoGridAngular/details-grid.component';

@NgModule({
  imports: [BrowserModule, BrowserAnimationsModule, GridModule, ReactiveFormsModule, DropDownsModule, PopupModule, InputsModule],
  declarations: [AppComponent, PopupAnchorDirective, DropDownListFilterComponent, GridComponent,DetailGridComponent],
  bootstrap: [AppComponent]
})

export class AppModule { }
