export const gridJSONData = [{
  'ProductID': 1,
  'ProductName': 'Chai',
  'SupplierID': 1,
  'CategoryID': 1,
  'CategoryName': 'Beverages',
  'QuantityPerUnit': '10 boxes x 20 bags',
  'UnitPrice': 18.0000,
  'UnitsInStock': 39,
  'UnitsOnOrder': 0,
  'ReorderLevel': 10,
  'Discontinued': false,
  children: [{
    id: 1,
    name: 'foo-child-1',
    children: [{
      id: 1,
      name: 'foo-child-1'
    }, {
      id: 2,
      name: 'foo-child-2'
    }]
  }, {
    id: 2,
    name: 'foo-child-2',
    children: [{
      id: 1,
      name: 'foo-child-1'
    }, {
      id: 2,
      name: 'foo-child-2'
    }]
  }]
}, {
  'ProductID': 2,
  'ProductName': 'Chang',
  'SupplierID': 1,
  'CategoryID': 1,
  'CategoryName': 'Beverages',
  'QuantityPerUnit': '24 - 12 oz bottles',
  'UnitPrice': 19.0000,
  'UnitsInStock': 17,
  'UnitsOnOrder': 40,
  'ReorderLevel': 25,
  'Discontinued': false,
  children: [{
    id: 3,
    name: 'bar-child-1',
    children: [{
      id: 3,
      name: 'bar-child-1'
    }, {
      id: 4,
      name: 'bar-child-2'
    }]
  }, {
    id: 4,
    name: 'bar-child-2',
    children: [{
      id: 3,
      name: 'bar-child-1'
    }]
  }, {
    id: 5,
    name: 'bar-child-3',
    children: [{
      id: 3,
      name: 'bar-child-1'
    }]
  }]
}, {
  'ProductID': 3,
  'ProductName': 'Aniseed Syrup',
  'SupplierID': 1,
  'CategoryID': 2,
  'CategoryName': 'Condiments',
  'QuantityPerUnit': '12 - 550 ml bottles',
  'UnitPrice': 10.0000,
  'UnitsInStock': 13,
  'UnitsOnOrder': 70,
  'ReorderLevel': 25,
  'Discontinued': false,
  children: [{
    id: 3,
    name: 'bar-child-1',
    children: [{
      id: 3,
      name: 'bar-child-1'
    }]
  }, {
    id: 4,
    name: 'bar-child-2',
    children: [{
      id: 3,
      name: 'bar-child-1'
    }]
  }, {
    id: 5,
    name: 'bar-child-3'
  }]
},];

export const categoryData = [
  {
    'CategoryID': 1,
    'CategoryName': 'Beverages',
    'Description': 'Soft drinks, coffees, teas, beers, and ales'
  },
  {
    'CategoryID': 2,
    'CategoryName': 'Condiments',
    'Description': 'Sweet and savory sauces, relishes, spreads, and seasonings'
  },
  {
    'CategoryID': 3,
    'CategoryName': 'Confections',
    'Description': 'Desserts, candies, and sweet breads'
  },
  {
    'CategoryID': 4,
    'CategoryName': 'Dairy Products',
    'Description': 'Cheeses'
  },
  {
    'CategoryID': 5,
    'CategoryName': 'Grains/Cereals',
    'Description': 'Breads, crackers, pasta, and cereal'
  },
  {
    'CategoryID': 6,
    'CategoryName': 'Meat/Poultry',
    'Description': 'Prepared meats'
  },
  {
    'CategoryID': 7,
    'CategoryName': 'Produce',
    'Description': 'Dried fruit and bean curd'
  },
  {
    'CategoryID': 8,
    'CategoryName': 'Seafood',
    'Description': 'Seaweed and fish'
  }
];

export const compassOneSampleJSON = [
  {
    ServiceID: 1,
    Service: "Mission Test",
    Name: "Test",
    ProjectRole: "Mission Test",
    Quantity: 10,
    ListRate: 270,
    BillRate: 10,
    CostRate: 169.11,
    Revenue: 10,
    DeliveryCost: 1691.10,
    SoldMargin: 0,
    Discount: 100,
    children: [
      {
        ServiceID: 1,
        Service: "Premier Field Engineer",
        Name: "Test premier sample",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "test Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          },
          {
            ServiceID: 2,
            Service: "Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          },
          {
            ServiceID: 3,
            Service: "test Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          },
          {
            ServiceID: 4,
            Service: "test Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          },
          {
            ServiceID: 5,
            Service: "test Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          },
          {
            ServiceID: 6,
            Service: "test Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 2,
        Service: "sample Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 3,
        Service: "Premier Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 4,
        Service: "Premier Field Engineer",
        Name: "Test premier sample",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "test Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 5,
        Service: "sample Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 6,
        Service: "Premier Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      }

      ,
      {
        ServiceID: 7,
        Service: "Test Premier",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 8,
        Service: "Test ",
        Name: "Test Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 9,
        Service: "Test Premier Field Engineer",
        Name: "Test Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 10,
        Service: "Test Premier Field Engineer",
        Name: "Test Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 11,
        Service: "Test Premier Field Engineer",
        Name: "Test Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 12,
        Service: "Test Premier Field Engineer",
        Name: "Test Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 13,
        Service: "Test Premier Field Engineer",
        Name: "Test Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 14,
        Service: "Test Premier Field Engineer",
        Name: "Test Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      }
    ]
  }, 
  {
    ServiceID: 2,
    Service: "Mission Critical Advisory Test",
    Name: "",
    ProjectRole: "Mission Critical Advisory Support Hours",
    Quantity: 10,
    ListRate: 270,
    BillRate: 0,
    CostRate: 169.11,
    Revenue: 0,
    DeliveryCost: 1691.10,
    SoldMargin: 0,
    Discount: 100,
    children: [
      {
        ServiceID: 1,
        Service: "Test Field Engineer",
        Name: "Test Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 2,
        Service: "Premier Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 2,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      }
    ]
  },
  {
    ServiceID: 3,
    Service: "Mission Critical Advisory Support Hours",
    Name: "",
    ProjectRole: "Mission Critical Advisory Support Hours",
    Quantity: 10,
    ListRate: 270,
    BillRate: 0,
    CostRate: 169.11,
    Revenue: 0,
    DeliveryCost: 1691.10,
    SoldMargin: 0,
    Discount: 100,
    children: [
      {
        ServiceID: 3,
        Service: "Premier Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 3,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      }
    ]
  }, {
    ServiceID: 4,
    Service: "Mission Critical Advisory Support Hours",
    Name: "",
    ProjectRole: "Mission Critical Advisory Support Hours",
    Quantity: 10,
    ListRate: 270,
    BillRate: 0,
    CostRate: 169.11,
    Revenue: 0,
    DeliveryCost: 1691.10,
    SoldMargin: 0,
    Discount: 100,
    children: [
      {
        ServiceID: 4,
        Service: "Premier Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 4,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      }
    ]
  }, {
    ServiceID: 5,
    Service: "Mission Critical Advisory Support Hours",
    Name: "",
    ProjectRole: "Mission Critical Advisory Support Hours",
    Quantity: 10,
    ListRate: 270,
    BillRate: 0,
    CostRate: 169.11,
    Revenue: 0,
    DeliveryCost: 1691.10,
    SoldMargin: 0,
    Discount: 100,
    children: [
      {
        ServiceID: 5,
        Service: "Premier Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 5,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      }
    ]
  },
  {
    ServiceID: 1,
    Service: "Mission Test",
    Name: "Test",
    ProjectRole: "Mission Test",
    Quantity: 10,
    ListRate: 270,
    BillRate: 10,
    CostRate: 169.11,
    Revenue: 10,
    DeliveryCost: 1691.10,
    SoldMargin: 0,
    Discount: 100,
    children: [
      {
        ServiceID: 1,
        Service: "Premier Field Engineer",
        Name: "Test premier sample",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "test Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 2,
        Service: "sample Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 3,
        Service: "Premier Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },{
        ServiceID: 1,
        Service: "Premier Field Engineer",
        Name: "Test premier sample",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "test Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 2,
        Service: "sample Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 3,
        Service: "Premier Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      }
    ]
  }, 
  {
    ServiceID: 2,
    Service: "Mission Critical Advisory Test",
    Name: "",
    ProjectRole: "Mission Critical Advisory Support Hours",
    Quantity: 10,
    ListRate: 270,
    BillRate: 0,
    CostRate: 169.11,
    Revenue: 0,
    DeliveryCost: 1691.10,
    SoldMargin: 0,
    Discount: 100,
    children: [
      {
        ServiceID: 1,
        Service: "Test Field Engineer",
        Name: "Test Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 1,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      },
      {
        ServiceID: 2,
        Service: "Premier Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 2,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      }
    ]
  },
  {
    ServiceID: 3,
    Service: "Mission Critical Advisory Support Hours",
    Name: "",
    ProjectRole: "Mission Critical Advisory Support Hours",
    Quantity: 10,
    ListRate: 270,
    BillRate: 0,
    CostRate: 169.11,
    Revenue: 0,
    DeliveryCost: 1691.10,
    SoldMargin: 0,
    Discount: 100,
    children: [
      {
        ServiceID: 3,
        Service: "Premier Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 3,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      }
    ]
  }, {
    ServiceID: 4,
    Service: "Mission Critical Advisory Support Hours",
    Name: "",
    ProjectRole: "Mission Critical Advisory Support Hours",
    Quantity: 10,
    ListRate: 270,
    BillRate: 0,
    CostRate: 169.11,
    Revenue: 0,
    DeliveryCost: 1691.10,
    SoldMargin: 0,
    Discount: 100,
    children: [
      {
        ServiceID: 4,
        Service: "Premier Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 4,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      }
    ]
  }, {
    ServiceID: 5,
    Service: "Page 2",
    Name: "",
    ProjectRole: "Mission Critical Advisory Support Hours",
    Quantity: 10,
    ListRate: 270,
    BillRate: 0,
    CostRate: 169.11,
    Revenue: 0,
    DeliveryCost: 1691.10,
    SoldMargin: 0,
    Discount: 100,
    children: [
      {
        ServiceID: 5,
        Service: "Premier Field Engineer",
        Name: "Premier Field Engineer",
        ProjectRole: "Premier Field Engineer",
        Quantity: 10,
        ListRate: 350,
        BillRate: 0,
        CostRate: 168.77,
        Revenue: 0,
        DeliveryCost: 1687.70,
        SoldMargin: 0,
        Discount: 100,
        children: [
          {
            ServiceID: 5,
            Service: "Premier Field Engineer",
            Name: "Premier Field Engineer",
            ProjectRole: "Premier Field Engineer",
            Quantity: 10,
            ListRate: 350,
            BillRate: 0,
            CostRate: 168.77,
            Revenue: 0,
            DeliveryCost: 1687.70,
            SoldMargin: 0,
            Discount: 100
          }
        ]
      }
    ]
  }
]
