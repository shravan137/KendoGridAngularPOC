import { Component } from '@angular/core';
import { gridJSONData, categoryData, compassOneSampleJSON } from './gridData';
import { products } from './products';
import { IColumn } from './column';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  public gridData: any;
  public dropdownData = categoryData;
  public columns: IColumn[] = [
    {
      field: 'ProductName',
      title: 'Product Name',
      type: 'text',
      required: true,
      isReadOnly: false,
      isSplitColumn:false,
      width:100
    },
    {
      field: 'CategoryID',
      title: 'Category',
      type: 'dropdown',
      required: false,
      isReadOnly: false,
      isSplitColumn:false,
      width:100
    }, {
      field: 'UnitPrice',
      format: '{0:c}',
      title: 'Unit Price',
      type: 'numeric',
      required: true,
      isReadOnly: false,
      isSplitColumn:false,
      width:100
    }, {
      field: 'UnitsInStock',
      title: 'Units In Stock',
      type: 'numeric',
      required: true,
      isReadOnly: false,
      isSplitColumn:false,
      width:100
    }
  ];

  public childColumns: IColumn[] = [
    {
      field: 'id',
      title: 'ID',
      type: 'numeric',
      required: true,
      isReadOnly: true,
      isSplitColumn:false,
      width:100
    },
    {
      field: 'name',
      title: 'Name',
      type: 'text',
      required: true,
      isReadOnly: false,
      isSplitColumn:false,
      width:100
    }
  ];

  public cOneParentGridColumns: IColumn[] = [    
    {
      field: 'Service',
      title: 'SERVICE',
      type: 'text',
      required: true,
      isReadOnly: false,
      isSplitColumn:false,
      width:120
    }
  ];

  public cOneColumns: IColumn[] = [    
    {
      field: 'Service',
      title: 'SERVICE',
      type: 'text',
      required: true,
      isReadOnly: false,
      isSplitColumn:false,
      width:120
    },
    {
      field: 'Name',
      title: 'NAME',
      type: 'text',
      required: true,
      isReadOnly: false,
      isSplitColumn:false,
      width:100
    },
    {
      field: 'ProjectRole',
      title: 'Project Role',
      type: 'text',
      required: true,
      isReadOnly: false,
      isSplitColumn:false,
      width:80
    },
    {
      field: 'Quantity',
      title: 'QTY',
      type: 'numeric',
      required: true,
      format: '{0:c}',
      isReadOnly: false,
      isSplitColumn:false,
      width:50
    },
    {
      field: 'ListRate',
      title: 'LIST RATE',
      type: 'numeric',
      required: true,
      format: '{0:c}',
      isReadOnly: false,
      isSplitColumn:false,
      width:50
    }
    // {
    //   field: 'BillRate',
    //   title: 'BILL RATE',
    //   type: 'numeric',
    //   required: true,
    //   format: '{0:c}',
    //   isReadOnly: false,
    //   isSplitColumn:true,
    //   width:50
    // },
    // {
    //   field: 'CostRate',
    //   title: 'COST RATE',
    //   type: 'numeric',
    //   required: true,
    //   format: '{0:c}',
    //   isReadOnly: false,
    //   isSplitColumn:true,
    //   width:50
    // },
    // {
    //   field: 'Revenue',
    //   title: 'REVENUE',
    //   type: 'numeric',
    //   required: true,
    //   format: '{0:c}',
    //   isReadOnly: false,
    //   isSplitColumn:false,
    //   width:60
    // },
    // {
    //   field: 'DeliveryCost',
    //   title: 'DELIVERY COST',
    //   type: 'numeric',
    //   required: true,
    //   format: '{0:c}',
    //   isReadOnly: false,
    //   isSplitColumn:false,
    //   width:80
    // },
    // {
    //   field: 'SoldMargin',
    //   title: 'SOLD MARGIN %',
    //   type: 'numeric',
    //   required: true,
    //   format: '{0:c}',
    //   isReadOnly: false,
    //   isSplitColumn:false,
    //   width:80
    // },
    // {
    //   field: 'Discount',
    //   title: 'DISCOUNT (PREMIUM)%',
    //   type: 'numeric',
    //   required: true,
    //   format: '{0:c}',
    //   isReadOnly: false,
    //   isSplitColumn:false,
    //   width:80
    // }
  ];
  constructor() {

    this.gridData = compassOneSampleJSON;
    // this.gridData = products;
    //alert(this.gridData);
  }

  gridDataSave(event: Event) {
    alert(event);
  }
}
